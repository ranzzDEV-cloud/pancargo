(function () {
  'use strict';

  const root = document.getElementById('app');
  const tx = (key, fallback) => document.querySelector(`#editable-copy [data-copy="${key}"]`)?.textContent || fallback;

  let state = null;
  let shell = null;
  let events = null;
  let refetchTimer = null;
  let clockOffset = 0;
  let lastQrNoticeKey = null;
  let notificationAudio = null;
  let supportWa = ''; 

  function unlockNotificationSound() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      notificationAudio = notificationAudio || new AudioCtx();
      if (notificationAudio.state === 'suspended') notificationAudio.resume();
    } catch (_) { /* browser mungkin tidak mendukung audio */ }
  }

  function playQrNotice() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      notificationAudio = notificationAudio || new AudioCtx();
      if (notificationAudio.state === 'suspended') notificationAudio.resume();
      const t = notificationAudio.currentTime;
      const osc = notificationAudio.createOscillator();
      const gain = notificationAudio.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(740, t);
      osc.frequency.setValueAtTime(990, t + 0.13);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.22, t + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
      osc.connect(gain).connect(notificationAudio.destination);
      osc.start(t);
      osc.stop(t + 0.44);
    } catch (_) { /* audio memerlukan interaksi pengguna di sebagian browser */ }
  }

  function installSupportButton() {
    if (document.getElementById('pancar-support')) return;
    const wrap = h('div', { id: 'pancar-support', class: 'support-float' });
    const button = h('button', { type: 'button', class: 'support-float-btn', 'aria-label': 'Hubungi admin' }, '✦');
    const label = h('span', { class: 'support-float-label' }, 'Chat admin');
    button.addEventListener('click', () => {
      let number = supportWa || '';
      try { number = number || localStorage.getItem('pancar_admin_wa') || ''; } catch (_) {}
      if (!number) {
        number = window.prompt('Masukkan nomor WhatsApp admin (format 628xxx):') || '';
        number = number.replace(/\D/g, '');
        if (number) {
          try { localStorage.setItem('pancar_admin_wa', number); } catch (_) {}
        }
      }
      if (!/^62\d{8,15}$/.test(number)) {
        toast('Nomor admin belum diatur atau formatnya salah.', 'bad');
        return;
      }
      window.open('https://wa.me/' + number + '?text=' + encodeURIComponent('Halo Admin PANCAR BLAST, saya membutuhkan bantuan.'), '_blank', 'noopener,noreferrer');
    });
    wrap.append(button, label);
    document.body.append(wrap);
  }

  function logo(extraClass) {
    return h('div', { class: `brand ${extraClass || ''}` }, h('img', { src: '/shared/logo.png', alt: '', width: 28, height: 28 }), h('span', { class: 'brand-name' }, 'PANCAR BLAST'));
  }

  /* ---------------- Masuk / daftar ---------------- */
  async function showAuth() {
    closeEvents();
    shell = null;
    let allowRegister = true;
    try {
      const pub = await api('GET', '/api/public');
      allowRegister = pub.allow_register;
      supportWa = String(pub.support_wa || '').replace(/\D/g, '');
    } catch {
      /* tetap tampilkan form */
    }

    let mode = 'login';
    const error = h('p', { class: 'form-error', role: 'alert' });
    const username = h('input', { type: 'text', id: 'f-user', autocomplete: 'username', required: true, maxlength: 20, autocapitalize: 'none', spellcheck: 'false' });
    const password = h('input', { type: 'password', id: 'f-pass', autocomplete: 'current-password', required: true, maxlength: 72 });
    const passHint = h('p', { class: 'hint', hidden: true }, 'Minimal 8 karakter.');
    const submit = h('button', { class: 'btn primary block', type: 'submit' }, 'Masuk');
    const tabLogin = h('button', { type: 'button', role: 'tab', 'aria-selected': 'true' }, 'Masuk');
    const tabRegister = h('button', { type: 'button', role: 'tab', 'aria-selected': 'false' }, 'Daftar');

    function setMode(next) {
      mode = next;
      tabLogin.setAttribute('aria-selected', String(next === 'login'));
      tabRegister.setAttribute('aria-selected', String(next === 'register'));
      submit.textContent = next === 'login' ? 'Masuk' : 'Buat akun';
      password.setAttribute('autocomplete', next === 'login' ? 'current-password' : 'new-password');
      passHint.hidden = next === 'login';
      error.textContent = '';
    }
    tabLogin.addEventListener('click', () => setMode('login'));
    tabRegister.addEventListener('click', () => setMode('register'));

    const form = h('form', { novalidate: true },
      h('div', { class: 'field' }, h('label', { for: 'f-user' }, 'Username'), username),
      h('div', { class: 'field' }, h('label', { for: 'f-pass' }, 'Kata sandi'), password, passHint),
      error,
      submit
    );
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      error.textContent = '';
      submit.disabled = true;
      try {
        await api('POST', mode === 'login' ? '/api/login' : '/api/register', { username: username.value, password: password.value });
        await boot();
      } catch (err) {
        error.textContent = err.message;
      } finally {
        submit.disabled = false;
      }
    });

    root.replaceChildren(
      h('div', { class: 'auth' },
        h('section', { class: 'auth-intro' },
          logo(),
          h('div', null,
            h('h1', null, tx('auth.title', 'Kelola koneksi WhatsApp dengan mudah')),
            h('p', { class: 'lead' }, tx('auth.subtitle', 'Masuk ke akun Anda, ajukan kode QR, lalu tunggu admin mengirimkannya secara langsung.'))
          ),
          h('ol', { class: 'flow' },
            h('li', null, h('div', null, h('strong', null, 'Minta kode QR'), h('span', null, 'Admin menerima permintaan Anda dan mengirim kodenya.'))),
            h('li', null, h('div', null, h('strong', null, 'Scan di WhatsApp'), h('span', null, 'Buka Perangkat tertaut, lalu arahkan kamera ke kode.'))),
            h('li', null, h('div', null, h('strong', null, 'Tunggu notifikasi'), h('span', null, 'Suara notifikasi muncul saat admin mengirim QR.')))
          )
        ),
        h('section', { class: 'auth-form-side' },
          h('div', { class: 'card auth-card' },
            allowRegister ? h('div', { class: 'tabs', role: 'tablist' }, tabLogin, tabRegister) : h('h2', { class: 'auth-title' }, 'Masuk'),
            form
          )
        )
      )
    );
    username.focus();
  }

  /* ---------------- Kerangka dasbor ---------------- */
  function buildShell() {
    const who = h('span', { class: 'who' });
    const header = h('header', { class: 'topbar' }, logo(), h('div', { class: 'topbar-right' }, who, h('button', { class: 'btn ghost sm', type: 'button', onclick: logout }, 'Keluar')));
    const welcome = h('section', { class: 'welcome card' },
      h('div', { class: 'welcome-icon' }, '✦'),
      h('div', null, h('h1', null, tx('welcome.title', 'Selamat datang di PANCAR BLAST')), h('p', { class: 'muted' }, tx('welcome.subtitle', 'Ajukan QR WhatsApp dan tunggu admin mengirimkannya.')))
    );
    const conn = h('section', { class: 'card conn', 'aria-labelledby': 'conn-title' });
    const overview = h('section', { class: 'overview-grid' });
    const history = h('section', { class: 'card history-card' });
    const withdraw = h('section', { class: 'card withdraw-card' });
    root.replaceChildren(header, h('main', { class: 'dashboard' }, welcome, overview, conn, history, withdraw));
    installSupportButton();
    return { who, conn, overview, history, withdraw };
  }

  async function logout() {
    try {
      await api('POST', '/api/logout');
    } catch {
      /* abaikan */
    }
    state = null;
    showAuth();
  }

  /* ---------------- Koneksi ---------------- */
  const STAGES = ['Minta QR', 'Admin menyiapkan', 'Scan QR', 'Terhubung'];
  const STAGE_INDEX = { none: 0, requested: 1, qr_ready: 2, scanned: 3, connected: 4 };

  async function act(fn, okMessage) {
    try {
      await fn();
      if (okMessage) toast(okMessage, 'ok');
    } catch (err) {
      toast(err.message, 'bad');
    }
    await refresh();
  }

  function openQrRequestDialog() {
    const dialog = h('dialog', { class: 'qr-request-dialog' });
    const close = () => dialog.close();
    dialog.append(
      h('div', { class: 'qr-dialog-head' }, h('span', null, '▦'), h('div', null, h('h2', null, 'Minta QR WhatsApp'), h('p', null, 'Permintaan akan dikirim ke admin'))),
      h('div', { class: 'qr-method selected' }, h('span', { class: 'qr-method-icon' }, '▦'), h('div', null, h('strong', null, 'QR Code'), h('p', null, 'Admin mengirim QR untuk dipindai dari WhatsApp di ponsel Anda.'))),
      h('div', { class: 'qr-dialog-actions' },
        h('button', { class: 'btn', type: 'button', onclick: close }, 'Batal'),
        h('button', { class: 'btn primary', type: 'button', onclick: async () => { unlockNotificationSound(); close(); await act(() => api('POST', '/api/qr/request'), 'Permintaan QR berhasil dikirim ke admin'); } }, 'Kirim permintaan →')
      )
    );
    document.body.append(dialog);
    dialog.addEventListener('close', () => dialog.remove(), { once: true });
    dialog.showModal();
  }

  function renderConn() {
    const status = state.user.conn_status;
    const current = STAGE_INDEX[status];
    const waiting = status === 'requested' || status === 'scanned';

    const stages = h('ol', { class: `stages ${waiting ? 'waiting' : ''}`, 'aria-label': 'Tahapan koneksi' },
      STAGES.map((label, i) => h('li', { class: i < current ? 'done' : i === current ? 'current' : '', 'aria-current': i === current ? 'step' : null }, label))
    );

    let body;
    if (status === 'none') {
      const rejected = state.qr && state.qr.status === 'rejected' && state.qr.note;
      body = h('div', { class: 'conn-body' },
        rejected && h('p', { class: 'notice bad' }, `Permintaan sebelumnya ditolak: ${state.qr.note}`),
        h('p', null, tx('connection.none', 'Hubungkan nomor WhatsApp Anda lewat kode QR. Admin akan menyiapkan kodenya.')),
        h('p', { class: 'notice' }, tx('connection.warning', 'Setelah QR tersedia, scan melalui menu Perangkat tertaut di WhatsApp. Jangan bagikan QR kepada siapa pun.')),
        h('button', { class: 'btn primary request-qr-btn', type: 'button', onclick: openQrRequestDialog }, tx('connection.request', '＋ Minta kode QR'))
      );
    } else if (status === 'requested') {
      body = h('div', { class: 'conn-body' },
        h('div', { class: 'waiting-qr' }, h('div', { class: 'qr-spinner' }), h('strong', null, 'Menunggu QR dari admin'), h('p', { class: 'muted' }, 'Permintaan Anda sudah masuk. Tetap buka halaman ini; QR akan muncul otomatis saat admin mengirimkannya.'), h('span', { class: 'live-indicator' }, '● Memantau secara realtime')),
        h('div', { class: 'btn-row' }, h('button', { class: 'btn', type: 'button', onclick: () => act(() => api('POST', '/api/qr/cancel')) }, 'Batalkan permintaan'))
      );
    } else if (status === 'qr_ready') {
      body = h('div', { class: 'conn-body' },
        h('div', { class: 'qr-frame' }, h('img', { src: `/api/qr/image?v=${state.qr ? state.qr.version : 0}`, alt: 'Kode QR untuk menautkan WhatsApp', width: 260, height: 260 })),
        h('ol', { class: 'steps-list' },
          h('li', null, 'Buka WhatsApp di ponsel Anda.'),
          h('li', null, 'Pilih Perangkat tertaut, lalu Tautkan perangkat.'),
          h('li', null, 'Arahkan kamera ke kode di atas.')
        ),
        h('div', { class: 'btn-row' },
          h('button', { class: 'btn primary', type: 'button', onclick: () => act(() => api('POST', '/api/qr/scanned')) }, 'Sudah saya scan'),
          h('button', { class: 'btn', type: 'button', onclick: () => act(() => api('POST', '/api/qr/request')) }, 'Minta QR baru')
        ),
        h('p', { class: 'hint' }, 'Kode QR cepat kedaluwarsa. Kalau gagal di-scan, minta kode baru.')
      );
    } else if (status === 'scanned') {
      body = h('div', { class: 'conn-body' },
        h('p', null, 'Scan diterima. Menunggu admin memastikan koneksinya.'),
        h('div', { class: 'btn-row' }, h('button', { class: 'btn', type: 'button', onclick: () => act(() => api('POST', '/api/qr/request')) }, 'Minta QR baru'))
      );
    } else {
      const { used_today: used, daily_limit: limit } = state.user;
      body = h('div', { class: 'conn-body' },
        h('p', { class: 'connected-line' }, 'WhatsApp berhasil terhubung'),
        h('p', { class: 'muted' }, `Kuota hari ini: ${used} dari ${limit} pesan.`),
        h('div', { class: 'btn-row' },
          h('button', {
            class: 'btn danger sm',
            type: 'button',
            onclick: () => {
              if (window.confirm('Putuskan sambungan nomor ini? Untuk blast berikutnya Anda perlu scan QR lagi.')) {
                act(() => api('POST', '/api/qr/disconnect'), 'Sambungan diputus');
              }
            },
          }, 'Putuskan sambungan')
        )
      );
    }

    shell.conn.replaceChildren(h('h2', { id: 'conn-title' }, tx('connection.title', 'Koneksi WhatsApp')), stages, body);
  }

  /* ---------------- Siklus data ---------------- */
  function rupiah(n) { return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(n || 0)); }

  function renderOverview() {
    const w = state.wallet || { balance: 0, lifetime_earned: 0, sent_total: 0, failed_total: 0, rate: 700 };
    const jobs = state.jobs || [];
    shell.overview.replaceChildren(
      h('div', { class: 'metric-card balance-card' }, h('span', { class: 'metric-label' }, tx('metric.balance', 'Saldo tersedia')), h('strong', { class: 'metric-value' }, rupiah(w.balance)), h('small', null, `Total penghasilan ${rupiah(w.lifetime_earned)}`)),
      h('div', { class: 'metric-card' }, h('span', { class: 'metric-label' }, tx('metric.sent', 'Pesan berhasil')), h('strong', { class: 'metric-value' }, String(w.sent_total || 0)), h('small', null, tx('metric.sent.note', 'Terkirim terverifikasi'))),
      h('div', { class: 'metric-card' }, h('span', { class: 'metric-label' }, tx('metric.failed', 'Pesan gagal')), h('strong', { class: 'metric-value' }, String(w.failed_total || 0)), h('small', null, tx('metric.failed.note', 'Tidak mendapat imbalan'))),
      h('div', { class: 'metric-card' }, h('span', { class: 'metric-label' }, tx('metric.rate', 'Tarif per pesan sukses')), h('strong', { class: 'metric-value' }, rupiah(w.rate)), h('small', null, tx('metric.rate.note', 'Dihitung otomatis')))
    );
    shell.history.replaceChildren(
      h('div', { class: 'section-head' }, h('div', null, h('h2', null, tx('report.title', 'Laporan & riwayat pengiriman')), h('p', { class: 'muted' }, `Total ${state.report?.jobs_total || 0} blast · ${state.report?.recipients_total || 0} nomor masuk antrean · ${state.report?.sent_today || 0} pesan terkirim hari ini`)), h('a', { class: 'btn', href: '/api/reports/export', download: 'laporan-pancar.csv' }, tx('report.download', 'Unduh laporan CSV'))),
      jobs.length ? h('div', { class: 'job-list' }, jobs.map(job => h('article', { class: 'job-row' },
        h('div', null, h('strong', null, `Blast #${job.id}`), h('small', null, new Date(job.created_at).toLocaleString('id-ID'))),
        h('div', { class: 'job-numbers' }, h('span', { class: 'sent-count' }, `✓ ${job.sent} terkirim`), h('span', { class: 'failed-count' }, `× ${job.failed} gagal`)),
        h('strong', { class: 'job-earned' }, rupiah((job.sent || 0) * 700))
      ))) : h('p', { class: 'muted' }, tx('report.empty', 'Belum ada riwayat pengiriman.'))
    );
    shell.withdraw.replaceChildren(
      h('div', { class: 'section-head' }, h('div', null, h('h2', null, tx('withdraw.title', 'Penarikan saldo')), h('p', { class: 'muted' }, tx('withdraw.subtitle', 'Minimal penarikan Rp10.000. Permintaan akan diperiksa admin.')))),
      h('button', { class: 'btn primary', type: 'button', onclick: openWithdrawDialog }, tx('withdraw.apply', 'Ajukan penarikan')),
      h('h3', null, tx('withdraw.activity', 'Aktivitas saldo')),
      h('div', { class: 'withdraw-history' }, (w.transactions || []).map(x => h('div', { class: 'withdraw-row' }, h('span', null, x.description), h('strong', { class: x.amount >= 0 ? 'sent-count' : 'failed-count' }, `${x.amount >= 0 ? '+' : ''}${rupiah(x.amount)}`)))),
      h('h3', null, tx('withdraw.status', 'Status penarikan')),
      h('div', { class: 'withdraw-history' }, (w.withdrawals || []).map(x => h('div', { class: 'withdraw-row' },
        h('span', null, h('strong', null, rupiah(x.amount)), h('small', null, `${x.bank_name} · ${x.account_number} · ${x.account_name}`), h('small', null, new Date(x.created_at).toLocaleString('id-ID')), x.note ? h('small', { class: 'muted' }, `Catatan admin: ${x.note}`) : null),
        h('span', { class: `status-${x.status}` }, x.status === 'pending' ? 'Menunggu' : x.status === 'approved' ? 'Disetujui' : 'Ditolak')
      )))
    );
  }

  function openWithdrawDialog() {
    const dialog = h('dialog', { class: 'qr-request-dialog' });
    const amount = h('input', { type: 'number', min: '10000', step: '1000', placeholder: 'Contoh: 50000', required: true });
    const bank = h('input', { type: 'text', maxlength: '60', placeholder: 'Nama bank / e-wallet', required: true });
    const number = h('input', { type: 'text', inputmode: 'numeric', maxlength: '30', placeholder: 'Nomor rekening', required: true });
    const owner = h('input', { type: 'text', maxlength: '80', placeholder: 'Nama pemilik rekening', required: true });
    const error = h('p', { class: 'form-error', role: 'alert' });
    const submit = h('button', { class: 'btn primary', type: 'button' }, 'Kirim permintaan');
    submit.addEventListener('click', async () => {
      submit.disabled = true; error.textContent = '';
      try { await api('POST', '/api/withdrawals', { amount: Number(amount.value), bank_name: bank.value, account_number: number.value, account_name: owner.value }); dialog.close(); toast('Permintaan penarikan dikirim ke admin.', 'ok'); await refresh(); }
      catch (e) { error.textContent = e.message; }
      finally { submit.disabled = false; }
    });
    dialog.append(h('div', { class: 'qr-dialog-head' }, h('span', null, '↗'), h('div', null, h('h2', null, tx('withdraw.apply', 'Ajukan penarikan')), h('p', null, `Saldo tersedia: ${rupiah(state.wallet?.balance || 0)}`))),
      h('div', { class: 'dialog-fields' }, amount, bank, number, owner, error),
      h('div', { class: 'qr-dialog-actions' }, h('button', { class: 'btn', type: 'button', onclick: () => dialog.close() }, 'Batal'), submit));
    document.body.append(dialog); dialog.addEventListener('close', () => dialog.remove(), { once: true }); dialog.showModal();
  }

  function render() {
    shell.who.textContent = state.user.username;
    renderOverview();
    renderConn();
  }

  async function refresh() {
    try {
      const previousQr = state && state.qr ? `${state.qr.status}:${state.qr.version}` : '';
      state = await api('GET', '/api/state');
      const nextQr = state && state.qr ? `${state.qr.status}:${state.qr.version}` : '';
      if (state.qr && state.qr.status === 'sent' && nextQr !== previousQr && lastQrNoticeKey !== nextQr) {
        lastQrNoticeKey = nextQr;
        playQrNotice();
        toast('QR WhatsApp sudah dikirim admin. Silakan buka halaman koneksi.', 'ok');
      }
      clockOffset = state.server_time - Date.now();
      if (!shell) shell = buildShell();
      render();
    } catch (err) {
      if (err.status === 401) {
        state = null;
        showAuth();
      } else {
        toast(err.message, 'bad');
      }
    }
  }

  function scheduleRefresh() {
    clearTimeout(refetchTimer);
    refetchTimer = setTimeout(refresh, 120);
  }

  function closeEvents() {
    if (events) events.close();
    events = null;
  }

  function openEvents() {
    closeEvents();
    events = new EventSource('/api/events');
    events.addEventListener('refresh', scheduleRefresh);
  }

  async function boot() {
    await refresh();
    if (state) openEvents();
  }

  // Hitung mundur ringan tanpa membangun ulang halaman.
  setInterval(() => {
    const job = state && state.active_job;
    if (!job || job.status !== 'waiting') return;
    const el = document.getElementById('countdown');
    if (!el) return;
    const left = Math.max(0, Math.ceil(START_ESTIMATE_SEC - secondsSinceCreated(job)));
    el.textContent = String(left);
    const text = document.getElementById('countdown-text');
    if (text) text.textContent = left > 0 ? 'Admin akan menjalankan bot sekitar waktu ini. Biarkan halaman tetap terbuka.' : 'Admin belum menekan jalankan. Mohon tunggu sebentar.';
  }, 500);

  // Cadangan bila koneksi realtime terputus.
  setInterval(() => {
    if (state && !document.hidden) refresh();
  }, 30000);

  boot();
})();
