'use strict';
// Muat konfigurasi .env lokal tanpa dependensi tambahan.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\\r?\\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const match = trimmed.match(/^([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[match[1]] === undefined) process.env[match[1]] = value;
  }
}
const worker = require('./lib/worker');
const auth = require('./lib/auth');
const { buildUserApp } = require('./lib/userApp');
const { buildAdminApp, ensureAdminPassword } = require('./lib/adminApp');

const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT || 3000);

async function main() {
  worker.recoverOnBoot();
  auth.purgeExpiredSessions();
  setInterval(() => auth.purgeExpiredSessions(), 3600e3).unref();

  const admin = ensureAdminPassword();
  const userApp = buildUserApp();
  const adminApp = buildAdminApp();

  // Satu proses dan satu port untuk Render Free: / untuk pengguna, /admin untuk admin.
  const server = http.createServer((req, res) => {
    let pathname = '/';
    try { pathname = new URL(req.url, 'http://localhost').pathname; } catch {}
    if (pathname === '/admin' || pathname.startsWith('/admin/')) {
      const original = req.url;
      req.url = req.url.replace(/^\/admin(?=\/|\?|$)/, '') || '/';
      if (req.url.startsWith('?')) req.url = '/' + req.url;
      adminApp.handle(req, res).finally(() => { req.url = original; });
      return;
    }
    userApp.handle(req, res);
  });

  await new Promise((resolve, reject) => {
    server.once('error', reject);
    server.listen(PORT, HOST, resolve);
  });

  console.log('Pancar berjalan pada satu server');
  console.log(`  Website pengguna : http://localhost:${PORT}/`);
  console.log(`  Dashboard admin  : http://localhost:${PORT}/admin`);
  console.log(`  Bot              : ${require('./bot/adapter').name}`);
  if (admin.password) {
    console.log('\n  Kata sandi admin (dibuat otomatis, hanya tampil sekali):');
    console.log(`  ${admin.password}`);
    console.log('  Simpan dengan aman; set ADMIN_PASSWORD di environment untuk deployment.');
  }
  return server;
}

if (require.main === module) {
  main().catch((err) => {
    console.error(err.message);
    process.exit(1);
  });
}

module.exports = { main };
