'use strict';
/*
 * ============================================================
 *  TITIK SAMBUNG BOT  (bagian ini yang Anda isi sendiri)
 * ============================================================
 * Platform memanggil tiga fungsi di bawah saat admin menjalankan blast.
 * Implementasi bawaan hanya SIMULASI: tidak ada pesan sungguhan yang dikirim.
 *
 * Alur sesi:
 *   1. Pengguna minta QR  -> admin menerima notifikasi di dashboard.
 *   2. Admin mengunggah gambar QR dari bot Anda -> muncul di web pengguna.
 *   3. Pengguna scan -> admin menekan "Konfirmasi terhubung".
 *      (Kalau bot Anda bisa mendeteksi koneksi sendiri, panggil endpoint admin
 *       POST /api/qr-requests/:id/connect dari bot supaya otomatis.)
 *   4. Pengguna menekan "Jalankan blast" -> admin menekan "Jalankan" -> worker
 *      memanggil prepare() sekali, send() per nomor (dengan jeda), lalu finish().
 *
 * Kontrak fungsi:
 *   prepare({ userId, jobId })            -> lempar Error bila sesi pengguna belum siap.
 *   send({ userId, jobId, number, text }) -> selesai tanpa error = terkirim;
 *                                            lempar Error = gagal (pesan error disimpan).
 *   finish({ userId, jobId })             -> bersih-bersih (opsional).
 *   disconnect({ userId })                -> dipanggil saat sambungan diputus (opsional).
 *
 * `number` sudah dinormalisasi (angka saja, contoh 6281234567890).
 * `text` sudah termasuk teks penutup (footer) dari pengaturan admin.
 */

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

module.exports = {
  name: 'simulasi',

  async prepare() {
    // Contoh nyata: pastikan sesi bot milik userId sudah login, kalau belum: throw new Error('Sesi belum siap')
  },

  async send({ number }) {
    await sleep(60 + Math.random() * 120);
    // Hanya untuk uji coba: nomor berakhiran 0000 selalu gagal.
    if (number.endsWith('0000')) throw new Error('Simulasi: nomor tidak terdaftar');
  },

  async finish() {},

  async disconnect() {},
};
