/* Helper kecil untuk kedua frontend. Semua teks dipasang lewat textContent / createTextNode (aman dari XSS). */
(function () {
  'use strict';

  window.h = function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const [key, value] of Object.entries(attrs)) {
        if (value == null || value === false) continue;
        if (key === 'class') el.className = value;
        else if (key.startsWith('on') && typeof value === 'function') el.addEventListener(key.slice(2), value);
        else if (value === true) el.setAttribute(key, '');
        else el.setAttribute(key, value);
      }
    }
    for (const kid of kids.flat(Infinity)) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  };

  window.api = async function api(method, url, body) {
    const init = { method, credentials: 'same-origin', headers: {} };
    if (method !== 'GET') {
      init.headers['content-type'] = 'application/json';
      init.body = JSON.stringify(body === undefined ? {} : body);
    }
    let res;
    try {
      res = await fetch(url, init);
    } catch {
      throw new Error('Tidak bisa terhubung ke server. Periksa koneksi internet Anda.');
    }
    let data = null;
    try {
      data = await res.json();
    } catch {
      /* bukan JSON */
    }
    if (!res.ok) {
      const err = new Error((data && data.error) || 'Permintaan gagal');
      err.status = res.status;
      throw err;
    }
    return data;
  };

  window.fmtDateTime = function (ms) {
    if (!ms) return '-';
    try {
      return new Date(ms).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    } catch {
      return new Date(ms).toISOString();
    }
  };

  window.timeAgo = function (ms) {
    const sec = Math.max(0, Math.round((Date.now() - ms) / 1000));
    if (sec < 10) return 'baru saja';
    if (sec < 60) return `${sec} dtk lalu`;
    if (sec < 3600) return `${Math.floor(sec / 60)} mnt lalu`;
    if (sec < 86400) return `${Math.floor(sec / 3600)} jam lalu`;
    return `${Math.floor(sec / 86400)} hari lalu`;
  };

  window.fmtDuration = function (sec) {
    sec = Math.max(0, Math.round(sec));
    if (sec < 60) return `${sec} detik`;
    const m = Math.round(sec / 60);
    if (m < 60) return `${m} menit`;
    return `${Math.floor(m / 60)} jam ${m % 60} menit`;
  };

  let toastWrap = null;
  window.toast = function (message, tone) {
    if (!toastWrap) {
      toastWrap = h('div', { class: 'toast-wrap', role: 'status', 'aria-live': 'polite' });
      document.body.append(toastWrap);
    }
    const el = h('div', { class: `toast ${tone || ''}` }, message);
    toastWrap.append(el);
    setTimeout(() => el.remove(), tone === 'bad' ? 6000 : 3800);
  };

  window.debounce = function (fn, ms) {
    let timer = null;
    return (...args) => {
      clearTimeout(timer);
      timer = setTimeout(() => fn(...args), ms);
    };
  };
})();
