(function () {
  'use strict';

  const root = document.getElementById('app');
  const tx = (key, fallback) => document.querySelector(`#editable-copy [data-copy="${key}"]`)?.textContent || fallback;
  const QR_LABEL = { pending: 'Perlu QR', sent: 'QR terkirim', scanned: 'Sudah scan', connected: 'Terhubung', rejected: 'Ditolak', cancelled: 'Dibatalkan', disconnected: 'Diputus' };
  const QR_TONE = { pending: 'warn', sent: 'signal', scanned: 'warn', connected: 'ok', rejected: 'bad', cancelled: '', disconnected: '' };
  const JOB_LABEL = { waiting: 'Menunggu', running: 'Berjalan', done: 'Selesai', stopped: 'Dihentikan', cancelled: 'Dibatalkan', failed: 'Gagal' };
  const JOB_TONE = { waiting: 'warn', running: 'signal', done: 'ok', stopped: 'bad', cancelled: '', failed: 'bad' };
  const CONN_LABEL = { none: 'Belum', requested: 'Minta QR', qr_ready: 'QR dikirim', scanned: 'Sudah scan', connected: 'Terhubung' };

  let shell = null;
  let tab = 'queue';
  let events = null;
  let refreshTimer = null;
  let soundOn = true;
  let audio = null;
  const pendingImages = new Map(); // id permintaan -> data URL gambar yang dipilih admin

  try {
    soundOn = localStorage.getItem('pancar_sound') !== 'off';
  } catch {
    /* penyimpanan tidak tersedia */
  }

  /* ---------------- Notifikasi ---------------- */
  function beep() {
    if (!soundOn) return;
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      if (audio.state === 'suspended') audio.resume();
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      const t = audio.currentTime;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, t);
      osc.frequency.setValueAtTime(1175, t + 0.14);
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.25, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.38);
      osc.connect(gain).connect(audio.destination);
      osc.start(t);
      osc.stop(t + 0.4);
    } catch {
      /* browser memblokir audio sebelum ada interaksi */
    }
  }

  function notify(title, body) {
    beep();
    toast(`${title}: ${body}`);
    if ('Notification' in window && Notification.permission === 'granted' && document.hidden) {
      try {
        new Notification(title, { body, tag: 'pancar-admin' });
      } catch {
        /* abaikan */
      }
    }
  }

  /* ---------------- Masuk ---------------- */
  function showLogin() {
    closeEvents();
    shell = null;
    const error = h('p', { class: 'form-error', role: 'alert' });
    const password = h('input', { type: 'password', id: 'a-pass', autocomplete: 'current-password', required: true });
    const submit = h('button', { class: 'btn primary block', type: 'submit' }, 'Masuk');
    const form = h('form', { novalidate: true }, h('div', { class: 'field' }, h('label', { for: 'a-pass' }, tx('login.password', 'Kata sandi admin')), password), error, submit);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      error.textContent = '';
      submit.disabled = true;
      try {
        await api('POST', '/admin/api/login', { password: password.value });
        await boot();
      } catch (err) {
        error.textContent = err.message;
      } finally {
        submit.disabled = false;
      }
    });
    root.replaceChildren(
      h('div', { class: 'login-wrap' },
        h('div', { class: 'card login-card' },
          h('div', { class: 'brand' }, h('img', { src: '/shared/logo.png', alt: '', width: 28, height: 28 }), h('span', { class: 'brand-name' }, 'PANCAR BLAST'), h('span', { class: 'admin-badge' }, 'Admin')),
          form
        )
      )
    );
    password.focus();
  }

  /* ---------------- Kerangka ---------------- */
  function buildShell() {
    const soundBtn = h('button', { class: 'btn sm', type: 'button' });
    const syncSound = () => {
      soundBtn.textContent = soundOn ? 'Suara notifikasi: aktif' : 'Suara notifikasi: mati';
      soundBtn.setAttribute('aria-pressed', String(soundOn));
    };
    syncSound();
    soundBtn.addEventListener('click', () => {
      soundOn = !soundOn;
      try {
        localStorage.setItem('pancar_sound', soundOn ? 'on' : 'off');
      } catch {
        /* abaikan */
      }
      syncSound();
      if (soundOn) {
        beep();
        if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
      }
    });

    const header = h('header', { class: 'topbar' },
      h('div', { class: 'brand' }, h('img', { src: '/shared/logo.png', alt: '', width: 28, height: 28 }), h('span', { class: 'brand-name' }, 'PANCAR BLAST'), h('span', { class: 'admin-badge' }, 'Admin')),
      h('div', { class: 'topbar-right' }, soundBtn, h('button', { class: 'btn ghost sm', type: 'button', onclick: logout }, 'Keluar'))
    );
    const summary = h('section', { class: 'summary', 'aria-label': 'Ringkasan' });
    const tabs = {};
    const nav = h('nav', { class: 'nav', role: 'tablist' });
    for (const [id, label] of [['queue', 'Antrean'], ['users', tx('users.title', 'Pengguna')], ['withdrawals', 'Penarikan'], ['settings', 'Pengaturan']]) {
      const btn = h('button', { type: 'button', role: 'tab', 'aria-selected': String(id === tab) });
      btn.addEventListener('click', () => {
        tab = id;
        for (const [key, el] of Object.entries(tabs)) el.setAttribute('aria-selected', String(key === id));
        for (const [key, pane] of Object.entries(panes)) pane.hidden = key !== id;
        refresh();
      });
      tabs[id] = btn;
      nav.append(btn);
      btn.dataset.label = label;
      btn.textContent = label;
    }
    const panes = {
      queue: h('div', { class: 'pane', role: 'tabpanel' }),
      users: h('div', { class: 'pane', role: 'tabpanel', hidden: true }),
      withdrawals: h('div', { class: 'pane', role: 'tabpanel', hidden: true }),
      settings: h('div', { class: 'pane', role: 'tabpanel', hidden: true }),
    };
    root.replaceChildren(header, summary, nav, panes.queue, panes.users, panes.withdrawals, panes.settings);
    return { summary, tabs, panes };
  }

  async function logout() {
    try {
      await api('POST', '/admin/api/logout');
    } catch {
      /* abaikan */
    }
    document.title = 'PANCAR BLAST | Admin';
    showLogin();
  }

  /* ---------------- Ringkasan ---------------- */
  function renderSummary(o) {
    const open = o.qr_pending + o.qr_scanned + o.jobs_waiting;
    document.title = `${open > 0 ? `(${open}) ` : ''}PANCAR BLAST | Admin`;
    const stat = (value, label, hot) => h('div', { class: `stat ${hot ? 'hot' : ''}` }, h('b', null, String(value)), h('span', null, label));
    shell.summary.replaceChildren(
      stat(o.qr_pending, 'Minta QR', o.qr_pending > 0),
      stat(o.qr_scanned, 'Menunggu konfirmasi', o.qr_scanned > 0),
      stat(o.jobs_waiting, 'Blast menunggu', o.jobs_waiting > 0),
      stat(o.jobs_running, 'Blast berjalan', false),
      stat(`${o.users_connected}/${o.users_total}`, 'Pengguna terhubung', false),
      stat(o.sent_today, 'Terkirim hari ini', false),
      stat(o.bot, 'Mode bot', false)
    );
    const dot = shell.tabs.queue;
    dot.replaceChildren('Antrean', open > 0 ? h('span', { class: 'count-dot' }, String(open)) : null);
  }

  /* ---------------- Antrean: permintaan QR ---------------- */
  function readImage(file) {
    return new Promise((resolve, reject) => {
      if (!file || !/^image\/(png|jpeg|webp)$/.test(file.type)) return reject(new Error('Pilih gambar PNG, JPG, atau WebP.'));
      if (file.size > 4 * 1024 * 1024) return reject(new Error('Gambar terlalu besar (maksimal 4 MB).'));
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(new Error('Gagal membaca gambar.'));
      reader.readAsDataURL(file);
    });
  }

  function qrCard(request) {
    const { id } = request;
    const canUpload = request.status === 'pending' || request.status === 'sent';
    const canConfirm = request.status === 'sent' || request.status === 'scanned';
    const image = pendingImages.get(id);

    let dropzone = null;
    let sendBtn = null;
    if (canUpload) {
      const fileInput = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', class: 'sr-only', tabindex: '-1' });
      const setImage = async (file) => {
        try {
          pendingImages.set(id, await readImage(file));
          renderQueue();
        } catch (err) {
          toast(err.message, 'bad');
        }
      };
      fileInput.addEventListener('change', () => {
        const file = fileInput.files[0];
        fileInput.value = '';
        if (file) setImage(file);
      });
      dropzone = h('div', { class: 'drop', tabindex: '0', role: 'button', 'aria-label': `Pilih atau tempel gambar QR untuk ${request.username}` },
        image ? h('img', { src: image, alt: 'Pratinjau kode QR yang akan dikirim' }) : null,
        h('span', null, image ? 'Klik untuk ganti gambar' : 'Klik untuk memilih gambar QR, seret ke sini, atau tempel dengan Ctrl+V'),
        fileInput
      );
      dropzone.addEventListener('click', () => fileInput.click());
      dropzone.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          fileInput.click();
        }
      });
      dropzone.addEventListener('paste', (e) => {
        const item = [...(e.clipboardData ? e.clipboardData.items : [])].find((i) => i.type.startsWith('image/'));
        if (item) {
          e.preventDefault();
          setImage(item.getAsFile());
        }
      });
      dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('over');
      });
      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('over'));
      dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('over');
        if (e.dataTransfer.files[0]) setImage(e.dataTransfer.files[0]);
      });
      sendBtn = h('button', { class: 'btn primary sm', type: 'button', disabled: !image }, request.status === 'sent' ? 'Kirim ulang QR' : 'Kirim QR');
      sendBtn.addEventListener('click', () => run(async () => {
        await api('POST', `/admin/api/qr-requests/${id}/send`, { image });
        pendingImages.delete(id);
      }, 'QR terkirim ke pengguna'));
    }

    const note = { pending: 'Menunggu Anda mengirim kode QR.', sent: 'QR sudah tampil di pengguna. Menunggu mereka scan.', scanned: 'Pengguna bilang sudah scan. Pastikan bot sudah terhubung, lalu konfirmasi.' }[request.status];

    return h('div', { class: `qr-card ${request.status === 'pending' || request.status === 'scanned' ? 'fresh' : ''}` },
      h('div', { class: 'qr-card-head' }, h('strong', null, request.username), h('span', { class: `pill ${QR_TONE[request.status]}` }, QR_LABEL[request.status])),
      h('p', { class: 'hint' }, `${note} Diminta ${timeAgo(request.created_at)}.`),
      dropzone,
      h('div', { class: 'btn-row' },
        sendBtn,
        canConfirm && h('button', { class: `btn sm ${request.status === 'scanned' ? 'primary' : ''}`, type: 'button', onclick: () => run(() => api('POST', `/admin/api/qr-requests/${id}/connect`), 'Pengguna ditandai terhubung') }, 'Konfirmasi terhubung'),
        h('button', {
          class: 'btn danger sm',
          type: 'button',
          onclick: () => {
            const reason = window.prompt('Alasan penolakan (akan terlihat oleh pengguna):', '');
            if (reason === null) return;
            run(() => api('POST', `/admin/api/qr-requests/${id}/reject`, { note: reason }), 'Permintaan ditolak');
          },
        }, 'Tolak')
      )
    );
  }

  /* ---------------- Antrean: blast ---------------- */
  async function openJob(id) {
    const dialog = h('dialog', null, h('div', { class: 'dialog-body' }, 'Memuat...'));
    document.body.append(dialog);
    dialog.addEventListener('close', () => dialog.remove());
    dialog.showModal();
    try {
      const { job, items } = await api('GET', `/admin/api/jobs/${id}`);
      const failed = items.filter((i) => i.status === 'failed');
      dialog.replaceChildren(
        h('div', { class: 'dialog-head' }, h('h2', null, `Blast ${job.username}`), h('button', { class: 'btn ghost sm', type: 'button', onclick: () => dialog.close() }, 'Tutup')),
        h('div', { class: 'dialog-body' },
          h('div', { class: 'field' }, h('span', { class: 'label' }, 'Pesan lengkap (termasuk teks penutup)'), h('div', { class: 'msg-box' }, job.message)),
          h('p', { class: 'num' }, `Terkirim ${job.sent}, gagal ${job.failed}, total ${job.total}, jeda ${job.delay_sec} detik.`),
          job.note && h('p', { class: 'muted' }, job.note),
          failed.length
            ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
                h('thead', null, h('tr', null, h('th', null, 'Nomor gagal'), h('th', null, 'Alasan'))),
                h('tbody', null, failed.map((i) => h('tr', null, h('td', { class: 'num' }, i.number), h('td', null, i.error || '-'))))
              ))
            : h('p', { class: 'muted' }, 'Belum ada pesan yang gagal.')
        )
      );
    } catch (err) {
      dialog.replaceChildren(h('div', { class: 'dialog-body' }, err.message));
    }
  }

  function jobRow(job) {
    const done = job.sent + job.failed;
    const pct = job.total ? Math.round((done / job.total) * 100) : 0;
    const fill = h('div', { class: 'bar-fill' });
    fill.style.width = `${pct}%`;
    const pending = job.total - done;
    return h('tr', null,
      h('td', null, h('strong', null, job.username), h('div', { class: 'hint num' }, timeAgo(job.created_at))),
      h('td', null, h('div', { class: 'job-preview' }, job.preview)),
      h('td', { class: 'progress-cell' }, h('div', { class: 'bar' }, fill), h('span', { class: 'hint num' }, `${job.sent} terkirim, ${job.failed} gagal, ${job.total} total`)),
      h('td', null, h('span', { class: `pill ${JOB_TONE[job.status] || ''}` }, JOB_LABEL[job.status] || job.status)),
      h('td', null, h('div', { class: 'row-actions' },
        job.status === 'waiting' && h('button', { class: 'btn primary sm', type: 'button', onclick: () => run(() => api('POST', `/admin/api/jobs/${job.id}/start`), 'Bot dijalankan') }, 'Jalankan'),
        job.status === 'stopped' && pending > 0 && h('button', { class: 'btn sm', type: 'button', onclick: () => run(() => api('POST', `/admin/api/jobs/${job.id}/start`), 'Dilanjutkan') }, 'Lanjutkan'),
        (job.status === 'running' || job.status === 'waiting') && h('button', { class: 'btn danger sm', type: 'button', onclick: () => run(() => api('POST', `/admin/api/jobs/${job.id}/stop`), 'Menghentikan...') }, 'Hentikan'),
        h('button', { class: 'btn ghost sm', type: 'button', onclick: () => openJob(job.id) }, 'Detail')
      ))
    );
  }

  let qrData = { open: [], recent: [] };
  let jobsData = [];

  function renderQueue() {
    const pane = shell.panes.queue;
    const qrSection = h('section', { class: 'card' },
      h('h2', null, tx('queue.qr', 'Permintaan QR'), h('span', { class: 'count' }, String(qrData.open.length))),
      qrData.open.length ? h('div', { class: 'stack' }, qrData.open.map(qrCard)) : h('p', { class: 'empty' }, 'Tidak ada permintaan. Notifikasi muncul di sini saat pengguna meminta QR.'),
      qrData.recent.length
        ? h('details', { class: 'recent' },
            h('summary', { class: 'hint' }, 'Riwayat terbaru'),
            h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' }, h('tbody', null, qrData.recent.map((r) => h('tr', null, h('td', null, r.username), h('td', null, h('span', { class: `pill ${QR_TONE[r.status]}` }, QR_LABEL[r.status])), h('td', { class: 'hint num' }, timeAgo(r.updated_at)))))))
          )
        : null
    );
    const jobSection = h('section', { class: 'card' },
      h('h2', null, tx('queue.blast', 'Antrean blast')),
      jobsData.length
        ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
            h('thead', null, h('tr', null, h('th', null, tx('users.title', 'Pengguna')), h('th', null, 'Pesan'), h('th', null, 'Progres'), h('th', null, 'Status'), h('th', { class: 'right' }, 'Aksi'))),
            h('tbody', null, jobsData.map(jobRow))
          ))
        : h('p', { class: 'empty' }, 'Belum ada blast.')
    );
    pane.replaceChildren(h('div', { class: 'queue-grid' }, qrSection, jobSection));
  }

  /* ---------------- Pengguna ---------------- */
  function renderUsers(users) {
    const pane = shell.panes.users;
    pane.replaceChildren(
      h('section', { class: 'card' },
        h('h2', null, tx('users.title', 'Pengguna'), h('span', { class: 'count' }, String(users.length))),
        users.length
          ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
              h('thead', null, h('tr', null, h('th', null, 'Username'), h('th', null, 'Koneksi'), h('th', null, 'Terpakai hari ini'), h('th', null, 'Kuota harian'), h('th', null, 'Akun'), h('th', { class: 'right' }, 'Aksi'))),
              h('tbody', null, users.map((u) => {
                const quota = h('input', { type: 'number', min: 1, max: 10000, value: u.daily_limit, 'aria-label': `Kuota harian ${u.username}` });
                return h('tr', null,
                  h('td', null, h('strong', null, u.username), h('div', { class: 'hint' }, `Daftar ${fmtDateTime(u.created_at)}`)),
                  h('td', null, h('span', { class: `pill ${u.conn_status === 'connected' ? 'ok' : u.conn_status === 'none' ? '' : 'warn'}` }, CONN_LABEL[u.conn_status] || u.conn_status)),
                  h('td', { class: 'num' }, String(u.used_today)),
                  h('td', null, h('div', { class: 'quota-form' }, quota, h('button', { class: 'btn sm', type: 'button', onclick: () => run(() => api('POST', `/admin/api/users/${u.id}`, { daily_limit: Number(quota.value) }), 'Kuota disimpan') }, 'Simpan'))),
                  h('td', null, h('span', { class: `pill ${u.banned ? 'bad' : 'ok'}` }, u.banned ? 'Diblokir' : 'Aktif')),
                  h('td', null, h('div', { class: 'row-actions' },
                    u.conn_status !== 'none' && h('button', {
                      class: 'btn sm', type: 'button',
                      onclick: () => window.confirm(`Putuskan sambungan ${u.username}? Blast yang berjalan ikut dihentikan.`) && run(() => api('POST', `/admin/api/users/${u.id}/disconnect`), 'Sambungan diputus'),
                    }, 'Putuskan'),
                    h('button', {
                      class: `btn sm ${u.banned ? '' : 'danger'}`, type: 'button',
                      onclick: () => (u.banned || window.confirm(`Blokir ${u.username}? Sesi login dan blast yang berjalan langsung dihentikan.`)) && run(() => api('POST', `/admin/api/users/${u.id}`, { banned: !u.banned }), u.banned ? 'Akun diaktifkan' : 'Akun diblokir'),
                    }, u.banned ? 'Aktifkan' : 'Blokir')
                  ))
                );
              }))
            ))
          : h('p', { class: 'empty' }, 'Belum ada pengguna terdaftar.')
      )
    );
  }

  /* ---------------- Penarikan saldo ---------------- */
  function renderWithdrawals(rows) {
    const pane = shell.panes.withdrawals;
    const pending = rows.filter((r) => r.status === 'pending');
    const totalPending = pending.reduce((sum, r) => sum + Number(r.amount || 0), 0);
    const rupiah = (n) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(Number(n || 0));
    const statusLabel = { pending: 'Menunggu', approved: 'Disetujui', rejected: 'Ditolak' };
    const table = rows.length ? h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
      h('thead', null, h('tr', null,
        h('th', null, 'Pengguna / Waktu'), h('th', null, 'Nominal'), h('th', null, 'Tujuan transfer'),
        h('th', null, 'Status / Catatan'), h('th', { class: 'right' }, 'Tindakan')
      )),
      h('tbody', null, rows.map((r) => h('tr', null,
        h('td', null, h('strong', null, r.username), h('div', { class: 'hint num' }, `#${r.id} · ${fmtDateTime(r.created_at)}`)),
        h('td', { class: 'num' }, h('strong', null, rupiah(r.amount))),
        h('td', null, h('strong', null, r.bank_name), h('div', { class: 'hint num' }, r.account_number), h('div', { class: 'hint' }, r.account_name)),
        h('td', null, h('span', { class: `pill ${r.status === 'pending' ? 'warn' : r.status === 'approved' ? 'ok' : 'bad'}` }, statusLabel[r.status] || r.status), r.note ? h('div', { class: 'hint' }, r.note) : null),
        h('td', null, r.status === 'pending' ? h('div', { class: 'row-actions' },
          h('button', { class: 'btn primary sm', type: 'button', onclick: () => {
            if (!window.confirm(`Pastikan transfer ${rupiah(r.amount)} kepada ${r.account_name} sudah berhasil dilakukan. Setujui penarikan #${r.id}?`)) return;
            const note = window.prompt('Catatan admin (opsional):', 'Transfer telah dilakukan.');
            if (note === null) return;
            run(() => api('POST', `/admin/api/withdrawals/${r.id}/approve`, { note }), 'Penarikan disetujui');
          } }, 'Setujui / sudah transfer'),
          h('button', { class: 'btn danger sm', type: 'button', onclick: () => {
            const note = window.prompt('Alasan penolakan (saldo akan dikembalikan):', 'Data rekening tidak valid.');
            if (note === null) return;
            if (!window.confirm(`Tolak penarikan #${r.id} dan kembalikan ${rupiah(r.amount)} ke saldo pengguna?`)) return;
            run(() => api('POST', `/admin/api/withdrawals/${r.id}/reject`, { note }), 'Penarikan ditolak dan saldo dikembalikan');
          } }, 'Tolak')
        ) : h('span', { class: 'hint' }, `Diproses ${fmtDateTime(r.updated_at)}`))
      )))
    )) : h('p', { class: 'empty' }, 'Belum ada permintaan penarikan.');
    pane.replaceChildren(
      h('section', { class: 'card' },
        h('div', { class: 'withdraw-summary' },
          h('div', null, h('span', { class: 'hint' }, 'Menunggu persetujuan'), h('strong', null, String(pending.length))),
          h('div', null, h('span', { class: 'hint' }, 'Total dana menunggu'), h('strong', null, rupiah(totalPending)))
        ),
        h('h2', null, tx('withdraw.title', 'Permintaan penarikan')),
        h('p', { class: 'hint' }, 'Lakukan transfer secara manual melalui bank/e-wallet terlebih dahulu, lalu pilih “Setujui / sudah transfer”. Jika ditolak, saldo pengguna otomatis dikembalikan.'),
        table
      )
    );
  }

  /* ---------------- Pengaturan ---------------- */
  function renderSettings(s) {
    const pane = shell.panes.settings;
    if (pane.dataset.built === '1' && pane.contains(document.activeElement)) return; // jangan ganggu saat sedang mengetik

    const autoStart = h('input', { type: 'checkbox', id: 's-auto', checked: s.auto_start });
    const allowReg = h('input', { type: 'checkbox', id: 's-reg', checked: s.allow_register });
    const minDelay = h('input', { type: 'number', id: 's-delay', min: 0, max: 120, value: s.min_delay_sec });
    const dailyDefault = h('input', { type: 'number', id: 's-daily', min: 1, max: 10000, value: s.default_daily_limit });
    const maxJob = h('input', { type: 'number', id: 's-max', min: 1, max: 5000, value: s.max_per_job });
    const footer = h('input', { type: 'text', id: 's-footer', maxlength: 200, value: s.footer_text });
    const saveBtn = h('button', { class: 'btn primary', type: 'submit' }, 'Simpan pengaturan');
    const form = h('form', { novalidate: true },
      h('div', { class: 'field check' }, autoStart, h('label', { for: 's-auto' }, 'Jalankan blast otomatis 15 detik setelah masuk antrean')),
      h('div', { class: 'field check' }, allowReg, h('label', { for: 's-reg' }, 'Izinkan pendaftaran pengguna baru')),
      h('div', { class: 'field' }, h('label', { for: 's-delay' }, 'Jeda minimum antar pesan (detik)'), minDelay, h('p', { class: 'hint' }, 'Pengguna tidak bisa memilih jeda di bawah angka ini.')),
      h('div', { class: 'field' }, h('label', { for: 's-daily' }, 'Kuota harian bawaan pengguna baru'), dailyDefault),
      h('div', { class: 'field' }, h('label', { for: 's-max' }, 'Maksimal nomor per blast'), maxJob),
      h('div', { class: 'field' }, h('label', { for: 's-footer' }, 'Teks penutup setiap pesan'), footer, h('p', { class: 'hint' }, 'Contoh: cara berhenti berlangganan. Kosongkan untuk menonaktifkan.')),
      saveBtn
    );
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      run(() => api('POST', '/admin/api/settings', {
        auto_start: autoStart.checked,
        allow_register: allowReg.checked,
        min_delay_sec: Number(minDelay.value),
        default_daily_limit: Number(dailyDefault.value),
        max_per_job: Number(maxJob.value),
        footer_text: footer.value,
      }), 'Pengaturan disimpan');
    });

    const current = h('input', { type: 'password', id: 'p-cur', autocomplete: 'current-password' });
    const next = h('input', { type: 'password', id: 'p-new', autocomplete: 'new-password' });
    const passForm = h('form', { novalidate: true },
      h('div', { class: 'field' }, h('label', { for: 'p-cur' }, 'Kata sandi saat ini'), current),
      h('div', { class: 'field' }, h('label', { for: 'p-new' }, 'Kata sandi baru'), next, h('p', { class: 'hint' }, 'Minimal 10 karakter.')),
      h('button', { class: 'btn', type: 'submit' }, 'Ganti kata sandi')
    );
    passForm.addEventListener('submit', (event) => {
      event.preventDefault();
      run(async () => {
        await api('POST', '/admin/api/password', { current: current.value, next: next.value });
        current.value = '';
        next.value = '';
      }, 'Kata sandi diganti');
    });

    pane.replaceChildren(
      h('div', { class: 'settings-grid' },
        h('section', { class: 'card' }, h('h2', null, tx('settings.delivery', 'Pengiriman dan pendaftaran')), form),
        h('section', { class: 'card' }, h('h2', null, tx('settings.security', 'Keamanan admin')), passForm)
      )
    );
    pane.dataset.built = '1';
  }

  /* ---------------- Siklus data ---------------- */
  async function run(fn, okMessage) {
    try {
      await fn();
      if (okMessage) toast(okMessage, 'ok');
    } catch (err) {
      toast(err.message, 'bad');
    }
    await refresh();
  }

  async function refresh() {
    try {
      const overview = await api('GET', '/admin/api/overview');
      if (!shell) shell = buildShell();
      renderSummary(overview);
      if (tab === 'queue') {
        [qrData, { jobs: jobsData }] = await Promise.all([api('GET', '/admin/api/qr-requests'), api('GET', '/admin/api/jobs')]);
        renderQueue();
      } else if (tab === 'users') {
        renderUsers((await api('GET', '/admin/api/users')).users);
      } else if (tab === 'withdrawals') {
        renderWithdrawals((await api('GET', '/admin/api/withdrawals')).withdrawals);
      } else {
        renderSettings(await api('GET', '/admin/api/settings'));
      }
    } catch (err) {
      if (err.status === 401) showLogin();
      else toast(err.message, 'bad');
    }
  }

  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, 150);
  }

  function closeEvents() {
    if (events) events.close();
    events = null;
  }

  function openEvents() {
    closeEvents();
    events = new EventSource('/admin/api/events');
    events.addEventListener('refresh', scheduleRefresh);
    events.addEventListener('job', scheduleRefresh);
    events.addEventListener('qr_request', (e) => {
      notify('Permintaan QR baru', `${JSON.parse(e.data).username} meminta kode QR`);
      scheduleRefresh();
    });
    events.addEventListener('qr_scanned', (e) => {
      notify('Sudah scan', `${JSON.parse(e.data).username} sudah scan, menunggu konfirmasi`);
      scheduleRefresh();
    });
    events.addEventListener('job_waiting', (e) => {
      const data = JSON.parse(e.data);
      notify('Blast baru', `${data.username} menunggu dijalankan (${data.total} nomor)`);
      scheduleRefresh();
    });
  }

  async function boot() {
    await refresh();
    if (shell) openEvents();
  }

  // Waktu relatif ("2 mnt lalu") dan cadangan bila koneksi realtime putus.
  setInterval(() => {
    if (shell && !document.hidden) refresh();
  }, 30000);

  boot();
})();
