'use strict';
// Uji end-to-end: menyalakan server sungguhan di port acak lalu menjalankan seluruh alur lewat HTTP.
const { spawn } = require('node:child_process');
const os = require('node:os');
const path = require('node:path');
const fs = require('node:fs');

const USER_PORT = 4100 + Math.floor(Math.random() * 400);
const U = `http://127.0.0.1:${USER_PORT}`;
const A = `${U}/admin`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pancar-'));
const ADMIN_PASSWORD = 'admin-uji-12345';

let passed = 0;
let failed = 0;
function check(name, cond, extra) {
  if (cond) {
    passed += 1;
    console.log(`  ok   ${name}`);
  } else {
    failed += 1;
    console.log(`  GAGAL ${name}${extra !== undefined ? ' -> ' + JSON.stringify(extra) : ''}`);
  }
}

function client(base, cookieName) {
  let cookie = '';
  return {
    async req(method, url, body, headers = {}) {
      const res = await fetch(base + url, {
        method,
        headers: { ...(method !== 'GET' ? { 'content-type': 'application/json' } : {}), ...(cookie ? { cookie } : {}), ...headers },
        body: method !== 'GET' && body !== undefined ? JSON.stringify(body) : method !== 'GET' ? '{}' : undefined,
      });
      const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
      for (const line of set) {
        const pair = line.split(';')[0];
        if (pair.startsWith(`${cookieName}=`)) cookie = pair.endsWith('=') ? '' : pair;
      }
      const type = res.headers.get('content-type') || '';
      const data = type.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer());
      return { status: res.status, data, headers: res.headers };
    },
    setCookie(value) {
      cookie = value;
    },
    getCookie: () => cookie,
  };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function waitFor(fn, ms = 8000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const v = await fn();
    if (v) return v;
    await sleep(100);
  }
  return null;
}

// PNG 1x1 valid
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';

async function main() {
  const server = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: { ...process.env, HOST: '127.0.0.1', PORT: String(USER_PORT), DB_PATH: path.join(dir, 'test.db'), ADMIN_PASSWORD },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = '';
  server.stdout.on('data', (d) => (log += d));
  server.stderr.on('data', (d) => (log += d));

  try {
    const up = await waitFor(async () => {
      try {
        const userUp = (await fetch(`${U}/api/public`)).ok;
        const adminUp = (await fetch(`${A}/api/session`)).status === 401;
        return userUp && adminUp;
      } catch {
        return false;
      }
    }, 10000);
    check('server menyala (pengguna + admin, satu port)', !!up, log.slice(-400));
    if (!up) throw new Error('server tidak menyala');

    const admin = client(A, 'pancar_admin');
    const user = client(U, 'pancar_sid');

    console.log('\nKeamanan dasar');
    let r = await admin.req('GET', '/api/overview');
    check('admin API tanpa login ditolak', r.status === 401, r.status);
    r = await user.req('GET', '/api/state');
    check('user API tanpa login ditolak', r.status === 401, r.status);
    r = await admin.req('POST', '/api/login', { password: 'salah' });
    check('login admin salah ditolak', r.status === 401, r.status);
    r = await fetch(`${A}/api/login`, { method: 'POST', headers: { 'content-type': 'text/plain' }, body: '{"password":"x"}' });
    check('POST non-JSON ditolak (415)', r.status === 415, r.status);
    r = await fetch(`${U}/..%2f..%2fserver.js`);
    check('path traversal ditolak', r.status === 404 || r.status === 400, r.status);
    r = await fetch(`${U}/`);
    check('halaman utama punya CSP', (r.headers.get('content-security-policy') || '').includes("script-src 'self'"));
    r = await fetch(`${A}/`);
    check('halaman dashboard admin terbuka di /admin', r.status === 200 && (await r.text()).includes('Dashboard Admin'));
    r = await fetch(`${A}/admin.js`);
    check('aset JavaScript admin terlayani melalui /admin', r.status === 200 && (r.headers.get('content-type') || '').includes('javascript'));
    r = await fetch(`${A}/admin.css`);
    check('aset CSS admin terlayani melalui /admin', r.status === 200 && (r.headers.get('content-type') || '').includes('css'));

    r = await admin.req('POST', '/api/login', { password: ADMIN_PASSWORD });
    check('login admin berhasil', r.status === 200, r.data);
    r = await admin.req('POST', '/api/settings', { min_delay_sec: 0, footer_text: 'Balas STOP untuk berhenti.' });
    check('admin ubah pengaturan (jeda 0 untuk uji)', r.status === 200 && r.data.min_delay_sec === 0, r.data);

    console.log('\nAkun pengguna');
    r = await user.req('POST', '/api/register', { username: 'a', password: 'passwordku123' });
    check('username terlalu pendek ditolak', r.status === 400, r.status);
    r = await user.req('POST', '/api/register', { username: 'budi_uji', password: 'passwordku123' });
    check('daftar berhasil', r.status === 201, r.data);
    r = await user.req('GET', '/api/state');
    check('state awal: belum terhubung', r.status === 200 && r.data.user.conn_status === 'none', r.data);
    const other = client(U, 'pancar_sid');
    r = await other.req('POST', '/api/register', { username: 'budi_uji', password: 'passwordku123' });
    check('username kembar ditolak', r.status === 409, r.status);

    console.log('\nAlur QR');
    r = await user.req('POST', '/api/jobs', { message: 'halo', numbers: '081234567890', consent: true });
    check('blast sebelum terhubung ditolak', r.status === 409, r.data);

    // SSE admin: harus menerima notifikasi permintaan QR
    const sseAbort = new AbortController();
    const sseRes = await fetch(`${A}/api/events`, { headers: { cookie: admin.getCookie() }, signal: sseAbort.signal });
    let sseText = '';
    (async () => {
      try {
        const reader = sseRes.body.getReader();
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          sseText += Buffer.from(value).toString();
        }
      } catch {}
    })();

    r = await user.req('POST', '/api/qr/request');
    check('minta QR berhasil', r.status === 200, r.data);
    const gotNotif = await waitFor(() => sseText.includes('event: qr_request'), 3000);
    check('admin menerima notifikasi realtime permintaan QR', !!gotNotif, sseText);

    r = await admin.req('GET', '/api/qr-requests');
    const req1 = r.data.open[0];
    check('permintaan muncul di dashboard admin', r.data.open.length === 1 && req1.username === 'budi_uji' && req1.status === 'pending', r.data);

    r = await admin.req('POST', `/api/qr-requests/${req1.id}/send`, { image: 'data:image/png;base64,AAAA' });
    check('gambar bukan PNG sungguhan ditolak', r.status === 400, r.data);
    r = await admin.req('POST', `/api/qr-requests/${req1.id}/send`, { image: 'data:image/svg+xml;base64,PHN2Zz48L3N2Zz4=' });
    check('SVG ditolak (cegah XSS)', r.status === 400, r.data);
    r = await admin.req('POST', `/api/qr-requests/${req1.id}/send`, { image: PNG });
    check('admin kirim QR berhasil', r.status === 200, r.data);

    r = await user.req('GET', '/api/state');
    check('state pengguna: QR siap', r.data.user.conn_status === 'qr_ready' && r.data.qr.has_image, r.data);
    r = await user.req('GET', '/api/qr/image');
    check('gambar QR tampil di sisi pengguna (image/png)', r.status === 200 && r.headers.get('content-type') === 'image/png' && r.data.length > 20, r.status);
    r = await other.req('GET', '/api/qr/image');
    check('pengguna lain tidak bisa ambil QR', r.status === 401, r.status);

    r = await user.req('POST', '/api/qr/scanned');
    check('pengguna menandai sudah scan', r.status === 200, r.data);
    check('admin menerima notifikasi sudah scan', !!(await waitFor(() => sseText.includes('event: qr_scanned'), 3000)));
    r = await admin.req('POST', `/api/qr-requests/${req1.id}/connect`);
    check('admin konfirmasi terhubung', r.status === 200, r.data);
    r = await user.req('GET', '/api/state');
    check('state pengguna: terhubung', r.data.user.conn_status === 'connected', r.data);

    console.log('\nBlast');
    r = await user.req('POST', '/api/numbers/check', { numbers: 'nama,nomor\nBudi,0812-3456-7890\n+62 812 3456 7890\n08123456781; 0812345670000\nabc123\n  \n6285700000001' });
    check('cek nomor: 4 valid, 1 duplikat, 1 tidak valid', r.data.valid === 4 && r.data.duplicates === 1 && r.data.invalid_count === 1, r.data);

    r = await user.req('POST', '/api/jobs', { message: 'Halo!', numbers: '081234567890', consent: false });
    check('tanpa persetujuan ditolak', r.status === 400, r.data);
    r = await user.req('POST', '/api/jobs', { message: '   ', numbers: '081234567890', consent: true });
    check('pesan kosong ditolak', r.status === 400, r.data);
    r = await user.req('POST', '/api/jobs', { message: 'Halo!', numbers: 'abc', consent: true });
    check('tanpa nomor valid ditolak', r.status === 400, r.data);

    r = await user.req('POST', '/api/jobs', {
      message: 'Halo, promo hari ini!',
      numbers: '081234567890\n081234567891\n081234567892\n0812345670000\n081234567893',
      delay_sec: 0,
      consent: true,
    });
    check('blast dibuat (menunggu admin)', r.status === 201, r.data);
    const jobId = r.data.id;
    check('admin menerima notifikasi blast baru', !!(await waitFor(() => sseText.includes('event: job_waiting'), 3000)));

    r = await user.req('POST', '/api/jobs', { message: 'dua', numbers: '081234567899', consent: true });
    check('blast kedua saat yang pertama aktif ditolak', r.status === 409, r.data);

    r = await user.req('GET', '/api/state');
    check('state pengguna: ada job aktif status waiting', r.data.active_job && r.data.active_job.status === 'waiting' && r.data.active_job.total === 5, r.data.active_job);

    r = await admin.req('GET', `/api/jobs/${jobId}`);
    check('pesan akhir memuat teks penutup', r.data.job.message.endsWith('Balas STOP untuk berhenti.'), r.data.job.message);

    r = await admin.req('POST', `/api/jobs/${jobId}/start`);
    check('admin menjalankan blast', r.status === 200, r.data);
    r = await admin.req('POST', `/api/jobs/${jobId}/start`);
    check('menjalankan dua kali ditolak', r.status === 409, r.data);

    const done = await waitFor(async () => {
      const s = (await user.req('GET', '/api/state')).data;
      return s.jobs[0].status === 'done' ? s : null;
    }, 15000);
    check('blast selesai', !!done);
    if (done) {
      const j = done.jobs[0];
      check('hasil: 4 terkirim, 1 gagal', j.sent === 4 && j.failed === 1, j);
      check('saldo bertambah Rp2.800 untuk 4 pesan sukses', done.wallet.balance === 2800 && done.wallet.lifetime_earned === 2800, done.wallet);
      check('laporan menampilkan total pesan terkirim dan gagal', done.report.sent_total === 4 && done.report.failed_total === 1 && done.report.jobs_total === 1, done.report);
      r = await user.req('GET', '/api/reports/export');
      check('pengguna dapat mengunduh laporan CSV', r.status === 200 && String(r.data).includes('Terkirim') && String(r.data).includes('Gagal') && r.headers.get('content-type').includes('text/csv'), r.status);
      r = await user.req('GET', `/api/jobs/${jobId}`);
      const failedItem = r.data.items.find((i) => i.status === 'failed');
      check('item gagal menyimpan alasan', failedItem && failedItem.number.endsWith('0000') && failedItem.error, r.data.items);
    }

    console.log('\nPenarikan saldo');
    // Isi saldo uji agar skenario penarikan dapat diuji tanpa mengubah tarif aplikasi.
    const { DatabaseSync } = require('node:sqlite');
    const testDb = new DatabaseSync(path.join(dir, 'test.db'));
    const walletUserId = (await admin.req('GET', '/api/users')).data.users.find((x) => x.username === 'budi_uji').id;
    testDb.prepare('UPDATE user_wallets SET balance = 20000 WHERE user_id = ?').run(walletUserId);
    testDb.close();
    r = await user.req('POST', '/api/withdrawals', { amount: 15000, bank_name: 'Bank Uji', account_number: '1234567890', account_name: 'Budi Uji' });
    check('pengguna mengajukan penarikan', r.status === 201, r.data);
    let withdrawalRows = (await admin.req('GET', '/api/withdrawals')).data.withdrawals;
    const withdrawalId = withdrawalRows[0]?.id;
    check('admin melihat detail rekening dan permintaan', !!withdrawalId && withdrawalRows[0].status === 'pending' && withdrawalRows[0].account_number === '1234567890');
    r = await admin.req('POST', `/api/withdrawals/${withdrawalId}/reject`, { note: 'Rekening perlu diperiksa' });
    check('admin menolak penarikan', r.status === 200, r.data);
    r = await user.req('GET', '/api/state');
    check('saldo otomatis dikembalikan setelah penolakan', r.data.wallet.balance === 20000 && r.data.wallet.withdrawals[0].status === 'rejected', r.data.wallet);
    r = await admin.req('POST', `/api/withdrawals/${withdrawalId}/approve`, {});
    check('penarikan yang sudah diproses tidak bisa disetujui ulang', r.status === 409, r.data);
    r = await user.req('POST', '/api/withdrawals', { amount: 12000, bank_name: 'Bank Uji', account_number: '1234567890', account_name: 'Budi Uji' });
    check('pengajuan penarikan kedua berhasil', r.status === 201, r.data);
    withdrawalRows = (await admin.req('GET', '/api/withdrawals')).data.withdrawals;
    const secondWithdrawalId = withdrawalRows.find((x) => x.status === 'pending')?.id;
    r = await admin.req('POST', `/api/withdrawals/${secondWithdrawalId}/approve`, { note: 'Transfer selesai' });
    check('admin menyetujui penarikan setelah transfer', r.status === 200, r.data);
    r = await user.req('GET', '/api/state');
    check('status disetujui tampil ke pengguna dan saldo sudah ditahan', r.data.wallet.balance === 8000 && r.data.wallet.withdrawals.some((x) => x.id === secondWithdrawalId && x.status === 'approved'), r.data.wallet);

    console.log('\nKuota & kontrol admin');
    r = await admin.req('GET', '/api/users');
    const uid = r.data.users[0].id;
    r = await admin.req('POST', `/api/users/${uid}`, { daily_limit: 7 });
    check('admin ubah kuota harian', r.status === 200, r.data);
    r = await user.req('POST', '/api/jobs', { message: 'lagi', numbers: '081234567801\n081234567802\n081234567803', delay_sec: 0, consent: true });
    check('melebihi kuota harian ditolak', r.status === 409 && /batas harian/i.test(r.data.error), r.data);

    r = await admin.req('POST', `/api/users/${uid}`, { daily_limit: 100 });
    r = await user.req('POST', '/api/jobs', { message: 'tunda', numbers: '081234567801', delay_sec: 0, consent: true });
    const jobId2 = r.data.id;
    r = await user.req('POST', `/api/jobs/${jobId2}/cancel`);
    check('pengguna bisa batalkan blast yang masih menunggu', r.status === 200, r.data);

    r = await user.req('POST', '/api/jobs', { message: 'panjang', numbers: Array.from({ length: 30 }, (_, i) => `0812345680${String(i).padStart(2, '0')}`).join('\n'), delay_sec: 1, consent: true });
    const jobId3 = r.data.id;
    await admin.req('POST', '/api/settings', { min_delay_sec: 1 });
    await admin.req('POST', `/api/jobs/${jobId3}/start`);
    await sleep(1800);
    r = await admin.req('POST', `/api/jobs/${jobId3}/stop`);
    check('admin menghentikan blast yang berjalan', r.status === 200, r.data);
    const stopped = await waitFor(async () => ((await admin.req('GET', `/api/jobs/${jobId3}`)).data.job.status === 'stopped' ? true : null), 5000);
    check('status job menjadi stopped', !!stopped);
    r = await admin.req('GET', `/api/jobs/${jobId3}`);
    check('sebagian terkirim sebelum dihentikan', r.data.job.sent > 0 && r.data.job.sent < 30, r.data.job);

    r = await admin.req('POST', `/api/users/${uid}/disconnect`);
    check('admin putuskan sambungan pengguna', r.status === 200, r.data);
    r = await user.req('GET', '/api/state');
    check('state pengguna kembali belum terhubung', r.data.user.conn_status === 'none', r.data.user);

    r = await admin.req('POST', `/api/users/${uid}`, { banned: true });
    r = await user.req('GET', '/api/state');
    check('pengguna yang diblokir langsung keluar', r.status === 401, r.status);
    r = await user.req('POST', '/api/login', { username: 'budi_uji', password: 'passwordku123' });
    check('pengguna diblokir tidak bisa masuk', r.status === 403, r.data);

    check('cookie pengguna tidak berlaku di dashboard admin', (await client(A, 'pancar_admin').req('GET', '/api/overview')).status === 401);

    sseAbort.abort();
  } finally {
    server.kill();
    fs.rmSync(dir, { recursive: true, force: true });
  }
  console.log(`\n${passed} lulus, ${failed} gagal`);
  process.exit(failed ? 1 : 0);
}

main().catch((err) => {
  console.error('Uji berhenti:', err.message);
  process.exit(1);
});
