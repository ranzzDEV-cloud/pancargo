# Pancar

Platform blast pesan dengan dua aplikasi terpisah yang berbagi satu backend dan satu database:

- **Website pengguna** (port 3000): daftar/masuk, minta kode QR, scan, susun dan jalankan blast, lihat riwayat.
- **Dashboard admin** (port 3001): notifikasi realtime (suara + notifikasi browser), kirim gambar QR, konfirmasi koneksi, jalankan/hentikan blast, kelola pengguna dan pengaturan.

Tanpa dependensi npm. Hanya butuh **Node.js 22.5 atau lebih baru**.

## Menjalankan

```bash
node server.js
```

Saat pertama jalan, kata sandi admin dibuat acak dan dicetak sekali di terminal. Untuk menentukan sendiri:

```bash
ADMIN_PASSWORD='kata-sandi-panjang-anda' node server.js
```

Lalu buka `http://127.0.0.1:3000` (pengguna) dan `http://127.0.0.1:3001` (admin).

Salin `.env.example` menjadi `.env` di folder utama proyek. Server otomatis membaca file `.env` saat startup; setelah mengubahnya, restart server. Pengaturan lewat environment: `HOST`, `PORT`, `DB_PATH`, `ADMIN_PASSWORD`, `SUPPORT_WA=628xxxxxxxxxx` (nomor WhatsApp admin untuk tombol chat mengambang), `COOKIE_SECURE=1` (wajib bila di belakang HTTPS), `TRUST_PROXY=1` (bila di belakang reverse proxy).

## Alur

1. Pengguna menekan **Minta kode QR** → dashboard admin bunyi dan menampilkan permintaan.
2. Admin mengunggah gambar QR dari bot (pilih file, seret, atau tempel dengan Ctrl+V) → QR muncul di halaman pengguna.
3. Pengguna scan lalu menekan **Sudah saya scan** → admin menekan **Konfirmasi terhubung**.
4. Pengguna mengisi pesan dan nomor, menekan **Jalankan blast** → muncul hitung mundur ±15 detik.
5. Admin menekan **Jalankan** → worker memanggil bot satu per satu dengan jeda; progres tampil realtime di kedua sisi.

Opsional: di Pengaturan, aktifkan "Jalankan blast otomatis 15 detik setelah masuk antrean" bila admin tidak mau menekan tombol manual.

## Menyambungkan bot Anda

Semua yang berhubungan dengan bot ada di satu file: **`bot/adapter.js`**. Bawaannya hanya simulasi (tidak mengirim apa pun). Isi `prepare`, `send`, `finish`, dan `disconnect` sesuai bot Anda; kontraknya dijelaskan di komentar file itu.

Kalau bot Anda bisa mendeteksi sendiri bahwa QR sudah di-scan, panggil `POST /api/qr-requests/:id/connect` di port admin (dengan sesi admin) supaya konfirmasi otomatis.

## Pengamanan yang sudah ada

- Kata sandi di-hash dengan scrypt; token sesi disimpan sebagai hash; cookie `HttpOnly` + `SameSite=Strict`.
- Cookie pengguna dan admin berbeda nama, dan API admin hanya ada di port admin.
- Semua POST wajib `application/json`; CSP ketat tanpa inline script; teks selalu dipasang lewat `textContent`.
- Unggahan QR dibatasi PNG/JPG/WebP, dicek isi file (bukan hanya ekstensi), maksimal 4 MB. SVG ditolak.
- Pembatas percobaan login, kuota harian per pengguna, jeda minimum, maksimal nomor per blast, satu blast aktif per pengguna.
- Pengguna wajib mencentang pernyataan persetujuan penerima, dan setiap pesan otomatis ditutup dengan teks berhenti berlangganan (bisa diubah admin).

Untuk produksi: pasang di belakang HTTPS (Nginx/Caddy), batasi akses port admin (VPN atau allowlist IP), dan cadangkan `data/app.db`.

## Saldo, laporan, dan database SQL

- Dashboard pengguna menampilkan saldo tersedia, total penghasilan, total pesan sukses/gagal, tarif, riwayat blast, aktivitas saldo, dan status penarikan.
- Setiap item pesan yang sukses diberi kredit Rp700 satu kali. ID item memiliki batas unik pada ledger agar retry tidak menggandakan kredit.
- Penarikan minimum Rp10.000; permintaan disimpan dengan status `pending` untuk ditinjau admin.
- Tombol chat admin mengambang memakai `SUPPORT_WA` dalam format internasional tanpa tanda `+`.
- Database aktif bawaan versi ini tetap SQLite di `data/app.db` (agar server yang sudah ada tetap kompatibel).
- Skema MySQL 8 disediakan di `database/mysql-schema.sql`. Itu adalah skema migrasi, **belum** berarti server otomatis terhubung ke MySQL. Migrasi backend ke MySQL memerlukan penggantian lapisan database dan pengujian deployment.

## Catatan penting

- Mengirim pesan massal lewat library WhatsApp tidak resmi melanggar ketentuan WhatsApp dan nomor yang dipakai bisa diblokir, terutama bila penerimanya tidak mengharapkan pesan. Untuk skala serius, pertimbangkan WhatsApp Business Platform resmi.
- Pengguna yang men-scan QR memberi akses ke akun WhatsApp mereka. Perlakukan sesi bot sebagai data sensitif dan jangan dipakai di luar blast yang diminta pengguna.

## Uji

```bash
npm test
```

Menyalakan server sungguhan di port acak dan menguji seluruh alur lewat HTTP (52 pemeriksaan: auth, QR, blast, kuota, penghentian, pemblokiran).

## Identitas merek dan penggantian logo

Logo bawaan berada di `shared/logo.png`. Untuk memakai logo milik sendiri:

1. Siapkan logo format PNG (disarankan transparan, persegi, minimal 256 × 256 px).
2. Buat salinan cadangan `shared/logo.png` terlebih dahulu.
3. Ganti file tersebut dengan logo milik Anda dan pertahankan nama persis `logo.png`.
4. Refresh browser dengan `Ctrl + F5`. Logo pengguna, admin, dan favicon akan memakai file yang sama.

Nama merek yang tampil di antarmuka dapat diubah melalui teks `PANCAR BLAST` pada `user-web/app.js` dan `admin-web/admin.js`.

## Tampilan antarmuka

Antarmuka menggunakan tema dark premium ungu-teal, dengan layout responsif untuk desktop dan ponsel. File tampilan utama:
- `shared/base.css` — warna global, tombol, formulir, tabel, dan komponen bersama.
- `user-web/app.css` — halaman masuk dan dashboard pengguna.
- `admin-web/admin.css` — halaman masuk dan dashboard admin.
